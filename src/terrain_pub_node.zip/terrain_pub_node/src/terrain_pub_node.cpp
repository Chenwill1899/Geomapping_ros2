#include <rclcpp/rclcpp.hpp>
#include <pcl_conversions/pcl_conversions.h>
#include <sensor_msgs/msg/point_cloud2.hpp>
#include <pcl/point_types.h>
#include <pcl/point_cloud.h>
#include <pcl/register_point_struct.h>
#include <cmath>

namespace velodyne_ros {
  struct EIGEN_ALIGN16 Point {
      PCL_ADD_POINT4D;
      float intensity;
      float time;
      uint16_t ring;
      EIGEN_MAKE_ALIGNED_OPERATOR_NEW
  };
}  // namespace velodyne_ros

POINT_CLOUD_REGISTER_POINT_STRUCT(velodyne_ros::Point,
    (float, x, x)
    (float, y, y)
    (float, z, z)
    (float, intensity, intensity)
    (float, time, time)
    (uint16_t, ring, ring)
)

class TerrainPubNode : public rclcpp::Node {
private:
    pcl::PointCloud<pcl::PointXYZI> pl_terrain;
    rclcpp::Publisher<sensor_msgs::msg::PointCloud2>::SharedPtr pubLaserCloudFull_terrain;
    rclcpp::Subscription<sensor_msgs::msg::PointCloud2>::SharedPtr sub_pcl;

public:
    TerrainPubNode() : Node("terrain_pub_node") {
        // 初始化发布者和订阅者
        sub_pcl = this->create_subscription<sensor_msgs::msg::PointCloud2>(
            "/velodyne_points", 100, 
            std::bind(&TerrainPubNode::standard_pcl_cbk, this, std::placeholders::_1));
        
        pubLaserCloudFull_terrain = this->create_publisher<sensor_msgs::msg::PointCloud2>(
            "/syncd_project_cloud", 10);
        
        RCLCPP_INFO(this->get_logger(), "Terrain publisher node initialized");
    }

private:
    void standard_pcl_cbk(const sensor_msgs::msg::PointCloud2::SharedPtr msg) 
    {
        float horizonAngle, range;
        pl_terrain.clear();
        
        // 预分配空间，但使用更合理的大小
        pl_terrain.points.reserve(32*1800);
        
        pcl::PointXYZI thisPoint;
        size_t rowIdn, columnIdn, index, cloudSize; 

        pcl::PointCloud<velodyne_ros::Point> pl_orig;

        try {
            pcl::fromROSMsg(*msg, pl_orig);
        } catch (const std::exception& e) {
            RCLCPP_ERROR(this->get_logger(), "Failed to convert ROS message to PCL: %s", e.what());
            return;
        }
        
        cloudSize = pl_orig.points.size();

        if (cloudSize == 0) {
            RCLCPP_WARN(this->get_logger(), "Received empty point cloud");
            return;
        }
        
        // 初始化地形点云为固定大小
        pl_terrain.points.resize(32*1800);
        for (auto& point : pl_terrain.points) {
            point.x = 0.0f;
            point.y = 0.0f;
            point.z = 0.0f;
            point.intensity = 0.0f;
        }

        for (size_t i = 0; i < cloudSize; ++i) {
            thisPoint.x = pl_orig.points[i].x;
            thisPoint.y = pl_orig.points[i].y;
            thisPoint.z = pl_orig.points[i].z;

            // 检查点是否有效
            if (std::isnan(thisPoint.x) || std::isnan(thisPoint.y) || std::isnan(thisPoint.z)) {
                continue;
            }

            // 找到图像中的行和列索引
            rowIdn = pl_orig.points[i].ring;
            
            if (rowIdn < 0 || rowIdn >= 32) {
                continue;
            }

            horizonAngle = atan2(thisPoint.x, thisPoint.y) * 180.0 / M_PI;

            columnIdn = -round((horizonAngle - 90.0) / 0.2) + 1800 / 2;
            if (columnIdn >= 1800) {
                columnIdn -= 1800;
            }

            if (columnIdn < 0 || columnIdn >= 1800) {
                continue;
            }

            range = sqrt(thisPoint.x * thisPoint.x + thisPoint.y * thisPoint.y + thisPoint.z * thisPoint.z);
            
            thisPoint.intensity = (float)rowIdn + (float)columnIdn / 10000.0;

            index = columnIdn + rowIdn * 1800;
            if (index < pl_terrain.points.size()) {
                pl_terrain.points[index] = thisPoint;
                pl_terrain.points[index].intensity = range; // 将点的对应距离保存为"强度"
            }
        }
        
        // 发布处理后的点云
        sensor_msgs::msg::PointCloud2 laserCloudmsg;
        try {
            pcl::toROSMsg(pl_terrain, laserCloudmsg);
            laserCloudmsg.header.stamp = this->now();
            laserCloudmsg.header.frame_id = "base_link";
            pubLaserCloudFull_terrain->publish(laserCloudmsg);
        } catch (const std::exception& e) {
            RCLCPP_ERROR(this->get_logger(), "Failed to convert PCL to ROS message: %s", e.what());
        }
    }
};

int main(int argc, char *argv[]) {
    rclcpp::init(argc, argv);
    auto node = std::make_shared<TerrainPubNode>();
    
    RCLCPP_INFO(node->get_logger(), "Starting terrain publisher node");
    
    rclcpp::spin(node);
    rclcpp::shutdown();
    return 0;
}
